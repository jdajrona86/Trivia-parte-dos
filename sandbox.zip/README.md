# quien_quiere_ser_millonario
Aplicación Front-end tipo Quien Quiere ser Millonario

Desarrolado como parte de la Trivia EP2023

HTML-CSS-SASS-JS
