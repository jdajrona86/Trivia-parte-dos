class preg {
  constructor(p, resp, op1, op2, op3) {
    this.p = p;
    this.resp = resp;
    this.op1 = op1;
    this.op2 = op2;
    this.op3 = op3;
  }

  op() {
    return [this.resp, this.op1, this.op2, this.op3].sort(
      (a, b) => Math.random() - 0.5,
    );
  }
}

uno = new preg(
  "¿Son propiedades físicas del petróleo:__________________?",
  "De color variable que va desde el pardo al negro",
  "Menos denso que el agua",
  "Combustible",
  "Ninguna de las opciones",
);
dos = new preg(
  "¿Qué es el petróleo?",
  "Mezcla de hidrocarburos",
  "De origen inorgánico",
  "Ninguna de las opciones",
  "Combustible fósil de origen químico",
);
tres = new preg(
  "¿Qué hace falta para que se forme el petróleo?",
  "Elevadas presiones",
  "Pupilas",
  "Cejas",
  "Anteojos",
);
cuatro = new preg(
  "Qué es la presión de yacimiento?",
  "Presión con la cual aportará la formación productora los Hc a través del sistema de producción y es necesario conocer para identificar el tipo de aparejo a utilizar",
  "Vitamina A",
  "Oxígeno",
  "Calcio",
);
cinco = new preg(
  "¿¿Cuál es la importancia de la toma de información al inicio y durante la vida productiva del yacimiento?",
  "Todas las opciones",
  "Micrómetro",
  "Dinamómetro",
  "Holometro",
);
seis = new preg(
  "¿Para qué se utilizan principalmente los registros de neutrón?",
  "tilizado para delinear formaciones porosas y para determinar porosidad",
  "El odio",
  "La envidia",
  "La esperanza",
);
siete = new preg(
  "¿Qué son pruebas de separador?",
  "Facilita los estudios para la caracterización de las propiedades dinámicas del yacimiento",
  "Federico Fellini",
  "Roman Polanski",
  "Franco Zeffirelli",
);
ocho = new preg(
  "Menciona cuáles son las herramientas de la caracterización dinámica de yacimientos",
  "Todas las opciones más pruebas de trazadores",
  "Madera",
  "Yeso",
  "Bronce",
);
nueve = new preg(
  "¿Qué es la caracterización dinámica de yacimientos?",
  "Proceso mediante el cual se identifican y evalúan los elementos que afectan la explotación de un yacimiento a través del análisis de variables que indican el comportamiento del sistema, tales como presión, flujo, temperatura, viscosidad y trazadores de elementos",
  "Viento Metal",
  "Viento madera",
  "Cuerda",
);
diez = new preg(
  "¿Cuáles son los mecanismos de empuje de un yacimiento?",
  "Todas las opciones",
  "Odio",
  "Miedo",
  "Trabajo",
);
once = new preg(
  "¿Cuál es el propósito principal de la deshidratación del petróleo?",
  "Todas las opciones",
  "Matutino",
  "Clandestino",
  "Pristino",
);
doce = new preg(
  "¿Cuál es el nombre de la ley que describe la velocidad de sedimentación de una gota de fase dispersa en una condición de flujo laminar?",
  "Ley de Stokes",
  " Oklahoma",
  "Arizona",
  "Colorado",
);
trece = new preg(
  "¿Cómo se llama el fenómeno que ocurre cuando un líquido se esparce sobre la superficie de otro líquido o de un sólido?",
  "Humectación",
  "La ardilla",
  "El caracol",
  "El loro",
);
catorce = new preg(
  "¿Cuál es el nombre del surfactante que tiene tanto una parte hidrofílica como una hidrofóbica en la misma molécula?",
  "No iónico",
  "Licuefacción",
  "Sublimación",
  "Solidificación",
);
quince = new preg(
  "¿Cómo se llama la emulsión que consiste en gotas de agua dispersas en aceite?",
  "Agua en aceite (W/O)",
  "Ovarios",
  "Pulmones",
  "Higado",
);
dieciseis = new preg(
  "¿Cuál es el nombre del agregado esférico de moléculas de surfactante que se forma en soluciones acuosas por encima de cierta concentración?",
  "Micela",
  "Ovarios",
  "Pulmones",
  "Higado",
);
diecisiete = new preg(
  "¿Cuál es el nombre de la empresa que desarrolló la Orimulsión?",
  "Petróleos de Venezuela S.A. (PDVSA)",
  "Ovarios",
  "Pulmones",
  "Higado",
);
dieciocho = new preg(
  "¿Cómo se llama la región de Venezuela donde se extrae el bitumen que se utiliza para la Orimulsión?",
  "Orinoco",
  "Ovarios",
  "Pulmones",
  "Higado",
);
diecinueve = new preg(
  "¿Cuál es el porcentaje aproximado de agua en la Orimulsión?",
  "30%",
  "Ovarios",
  "Pulmones",
  "Higado",
);
veinte = new preg(
  "¿Cuál es el propósito de un pozo de petróleo?",
  "Conectar el yacimiento en subsuelo con la superficie",
  "Ovarios",
  "Pulmones",
  "Higado",
);

const preguntas = [
  uno,
  dos,
  tres,
  cuatro,
  cinco,
  seis,
  siete,
  ocho,
  nueve,
  diez,
  once,
  doce,
  trece,
  catorce,
  quince,
  dieciseis,
  diecisiete,
  dieciocho,
  diecinueve,
  veinte,
]
  .sort((a, b) => Math.random() - 0.5)
  .slice(0, 15);

//Funciones necesarias para el juego
function aparecer_ventana() {
  //ventana de comoddines y mensajes
  ventana.style.transform = "scale(1)";
  document.getElementById(identificacion).style.display = "block";
  clearInterval(intrv);
}

btn_comodin.onclick = () => {
  ventana.style.transform = "scale(0)";
  document.getElementById(identificacion).style.display = "none";

  if (identificacion == "resp_correcta") {
    cambiar_pregunta(preguntas[nivel].p, preguntas[nivel].op());
  }
  temporizador();
};

function cambiar_pregunta(p, r) {
  //funcion para cambiar la pregunta p=pregunta r=array con las respuestas
  pregunta.innerText = p;

  for (var i = 0; i < 4; i++) {
    respuestas[i].innerText = r[i];
  }

  cont_tiempo = 31;
}

function felicidades() {
  //Mensaje Ganador
  ventana2.style.transform = "scale(1)";
  victoria.style.display = "inline-block";
  ganado.innerText = ganado.innerText + " " + dinero_ganado;
}

function perder() {
  //Mensaje Perdedor
  if (sonar) {
    intro.muted = true;
    m_perdiste.play();
  }
  ventana2.style.transform = "scale(1)";
  clearInterval(intrv);
  victoria.innerHTML = "¡Haz perdido! Intenta nuevamente";
  victoria.style.display = "inline-block";
  document
    .getElementById("img_vent")
    .setAttribute("src", "medios/img/perder.jpg");
  ganado.innerText = ganado.innerText + " " + dinero_ganado;
}

//Cambio y corrección de las preguntas del juego
//Además, por cada pregunta correcta se acumula una recompenza
cambiar_pregunta(preguntas[nivel].p, preguntas[nivel].op());

for (let i = 0; i < respuestas.length; i++) {
  resp[i].onclick = () => {
    if (respuestas[i].innerText == preguntas[nivel].resp) {
      identificacion = "resp_correcta";
      if (sonar) m_correcto.play();
      nivel++;
      pasaste.innerText = "Pasaste al nivel:" + (nivel + 1);
      aparecer_ventana();
      recompenza = recompenza + 10000 * nivel;

      if (nivel > preguntas.length - 1) {
        dinero_ganado = recompenza;
        felicidades();
      } else {
        if (nivel % 5 == 0) {
          dinero_ganado = recompenza; //cada vez supera un nivel (5preguntas)
          dinero.innerText = dinero_ganado;
        }
      }
    } else perder();
  };
}

//Comodines de ayuda a la resolución de las preguntas

cont_comodin.addEventListener("click", (e) => {
  if (e.target.classList.contains("comodines")) {
    e.target.style.backgroundColor = "gray";
  }

  if ((amigo == false) & e.target.classList.contains("icon-phone")) {
    amigo = true;
    identificacion = "llamar";
    aparecer_ventana();
    document.getElementById("correcto").innerText = preguntas[nivel].resp;
  } else if ((publico == false) & e.target.classList.contains("icon-users")) {
    publico = true;
    identificacion = "audiencia";
    aparecer_ventana();
    for (var i = 0; i < 4; i++) {
      if (respuestas[i].innerText == preguntas[nivel].resp)
        barra[i].value = "70";
    }
  } else if ((mitad == false) & e.target.classList.contains("mitad")) {
    mitad = true;
    let aux1 = 0;
    for (var i = 0; (i < 4) & (aux1 < 2); i++) {
      if (respuestas[i].innerText != preguntas[nivel].resp) {
        aux1++;
        respuestas[i].innerText = "";
      }
    }
  }
});

//Botones para rendirse o terminar el juego
rendirse.onclick = () => {
  ventana2.style.transform = "scale(1)";
  ganado.innerText = ganado.innerText + " " + dinero_ganado;
};

terminar.onclick = () => {
  //Una vez termina el juego se recarga la pagina y vuelve al inicio
  location.reload();
};
